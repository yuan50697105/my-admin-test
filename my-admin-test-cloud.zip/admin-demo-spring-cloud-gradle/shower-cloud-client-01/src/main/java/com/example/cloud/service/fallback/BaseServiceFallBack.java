package com.example.cloud.service.fallback;

import com.example.cloud.service.BaseService;
import org.springframework.stereotype.Component;

/**
 * @program: admin-demo-spring-cloud-gradle
 * @description:
 * @author: yuane
 * @create: 2020-04-18 20:13
 */
@Component
public class BaseServiceFallBack implements BaseService {
    @Override
    public String aaa() {
        return "aaa fallback";
    }
}